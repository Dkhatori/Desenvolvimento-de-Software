import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        Conta conta1 = new Conta();

        System.out.println("Digite o nome");
        String n = sc.next(); // Lendo do teclado

        System.out.println("Digite o Saldo");
        double s = sc.nextDouble();

        System.out.println("Digite o Número");
        int num = sc.nextInt();

        System.out.println("Digite o limite");
        double l = sc.nextDouble();

        conta1.setNome(n); // Usando set
        conta1.setSaldo(s);
        conta1.setNumero(num);
        conta1.setLimite(l);

        System.out.println("O nome digitado é: " + conta1.getNome());
        System.out.println("O valor digitado é: " + conta1.getSaldo());
        System.out.println("O número digitado é: " + conta1.getNumero());
        System.out.println("O limite digitado é: " + conta1.getLimite());
        // Conta 2
        Conta conta2 = new Conta();
        conta2.setNumero(5);
        // Visualiza contas
        System.out.println(conta1.toString());
        System.out.println(conta2.toString());
        // Conta 3
        Conta conta3 = new Conta();
        System.out.println(conta3.toString());
        sc.close(); // fechar o Scanner
    }
}
