public class Funcionario02 {
    String nome; 
    String Departamento;
    String Data;
    String RG;
    double salario;
    boolean estaNaEmpresa;

    void bonifica(double salario){
            this.salario += salario;
        }
    }

    void demite(){
        this.estaNaEmpresa = false;
    }

    void mostrarDados(){
        System.out.println("\n-- Dados do Funcionário --");
        System.out.println("Nome: " = + this.nome);
    }
}

/*void mostrarDados(){
    String status = this.estaNaEmpresa ? "Sim": "Não";

    String ficha= """
            +-------------------------------------------------+
                          FICHA DO FUNCIONARIO
            +-------------------------------------------------+
            |Nome: %s|
            |Departamento: %s|
            |Salario: 2f|
            |Data de Entrada: %s|
            |RG: %s|
            |Status: %s|
            +-------------------------------------------------+
            """.formatted(...args: this.nome, this.Departamento, this.salario, this.RG, this.Status);
            System.out.println(ficha);
}*\ 


