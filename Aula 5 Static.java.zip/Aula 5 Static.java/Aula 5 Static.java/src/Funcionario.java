import java.util.Scanner;

public class Funcionario {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Funcionario02 f1 = new Funcionario02();

        System.out.println("Digite seu nome: ");
        f1.nome = sc.nextLine();

        sc.close();
    }
}
